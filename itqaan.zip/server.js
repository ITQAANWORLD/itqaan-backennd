const express = require('express');
const authenticationRoutes = require('./src/routes/auth');
const mpesaRoutes = require('./src/routes/mpesa');
const paymentRoutes = require('./src/routes/payments');
const serviceRoutes = require('./src/routes/services');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json()) 
app.use(express.urlencoded({ extended: true })) 

//Routes
app.use('/services', serviceRoutes);
app.use('/payments', paymentRoutes);
app.use('/mpesa', mpesaRoutes);
app.use('/', authenticationRoutes);

app.get('/', (req, res) => {
     res.send("Welcome to itqaan backend ");
});

app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
})