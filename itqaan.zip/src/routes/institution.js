const express = require('express')
const pool = require('../models/dbconfig');

const router = express.Router();

// middleware
router.use(serviceMiddleware);

router.post('/', (req,res) => {
    pool.getConnection((err,connection) => {
        if(err) throw err;
        connection.query('SELECT * FROM institution', [] , (error,rows) => {
            if(error) throw error;

            connection.release();
            if(rows.length > 0) {
                return res.json({
                    "status" : "Success",
                    "message" : "log successful"  ,
                    "data" : rows,
                   });
                
                
            } else {
                return res.json({
                    "status" : "Error",
                    "message" : "Failed to fetch data ",
                   });
            }
            
        })
    })
});

router.post('/:id', (req,res) => {
    const id = req.params.id;
    pool.getConnection((err,connection) => {
        if(err) throw err;
        connection.query('SELECT * FROM institution where id = ?', [id] , (error,rows) => {
            if(error) throw error;

            connection.release();
            if(rows.length > 0) {
                return res.json({
                    "status" : "Success",
                    "message" : "Data fetched"  ,
                    "data" : rows,
                   });
                
                
            } else {
                return res.json({
                    "status" : "Error",
                    "message" : "Failed to fetch data ",
                   });
            }
            
        })
    })
});

function serviceMiddleware(req,res,next) {
    console.log(`Time  ${Date.now().toString()}  ${req.method} ${req.originalURL}` );
    next();
}

module.exports = router;